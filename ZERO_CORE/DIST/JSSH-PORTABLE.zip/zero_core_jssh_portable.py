#!/usr/bin/env python3
import os
import json
import hashlib

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STATE = os.path.join(ROOT, "PANDEMONIUM", "state", "JSSH_PORTABLE.json")

LICENSE_NO = "JSSH-2026-0001"


def percent(payload):
    checks = []

    for item in payload.get("payload", {}).values():
        if isinstance(item, dict):
            checks.append(item.get("state") == "PRESENT")

    checks.append(bool(payload.get("license", {}).get("number")))
    checks.append(bool(payload.get("integrity", {}).get("digest")))

    if not checks:
        return 0

    return int(sum(checks) * 100 / len(checks))


def display_path(path):
    path = os.path.abspath(path)

    if path == ROOT:
        return "~"

    if path.startswith(ROOT + os.sep):
        return "~/" + os.path.relpath(path, ROOT)

    return path


def load():
    with open(STATE, encoding="utf-8") as f:
        return json.load(f)


def save(data):
    tmp = STATE + ".tmp"

    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")

    os.replace(tmp, STATE)


def update_prompt(data, path):
    data["prompt"] = {
        "mode": "PATH_DERIVED",
        "license": LICENSE_NO,
        "current_path": display_path(path),
        "movement": {
            "enabled": True,
            "operation": "CD",
            "display": "PATH"
        }
    }


def show(data):
    print()
    print("JSSH %d%%___" % percent(data))
    print("│≡ LICENSE No. ▫️ %s" % LICENSE_NO)
    print("│≡ PATH ▫️ %s" %
          data["prompt"]["current_path"])
    print("└#→")


def main():
    data = load()

    current = os.getcwd()

    update_prompt(data, current)
    save(data)

    show(data)


if __name__ == "__main__":
    main()
